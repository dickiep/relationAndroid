package com.dickies.android.relationbn.utils;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Phil on 28/09/2018.
 */

public class User {

    private String userName;

    public User() {

    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

}
