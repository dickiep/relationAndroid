package com.dickies.android.relationbn;


import android.app.Application;
//import io.mapwize.mapwizeformapbox.AccountManager;
/**
 * Created by Phil on 17/07/2018.
 */

public class RelationBN extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        //AccountManager.start(this, "b78c4bb586011db66b193bbed179f11e");
    }


}
